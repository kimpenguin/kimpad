// # in app/assets/javascripts/ckeditor/config.js

CKEDITOR.editorConfig = function (config) {

  config.toolbar_mini = [
    ["Bold",  "Italic", "Format",  "-", "BulletedList", "NumberedList", "-", "Source"],
  ];
  config.toolbar = 'mini';
}
